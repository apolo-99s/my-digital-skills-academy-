# 🇩🇿 Digital Skills Academy — Guide de Déploiement & Vente

---

## ÉTAPE 1 — Mettre en ligne (Vercel, GRATUIT, 10 minutes)

### 1.1 Créer un compte GitHub
1. Allez sur **github.com** → Sign Up (gratuit)
2. Créez un nouveau repository : cliquez **New** → nommez-le `digital-skills-academy` → Public → Create

### 1.2 Upload les fichiers
1. Dans votre repo GitHub, cliquez **Add file → Upload files**
2. Uploadez TOUS les fichiers de ce dossier en respectant la structure :
   ```
   /public/index.html
   /src/index.js
   /src/App.js
   /src/Academy.jsx
   /package.json
   /vercel.json
   ```
3. Cliquez **Commit changes**

### 1.3 Déployer sur Vercel
1. Allez sur **vercel.com** → Sign Up with GitHub
2. Cliquez **Add New Project** → Import votre repo `digital-skills-academy`
3. Framework Preset → sélectionnez **Create React App**
4. Cliquez **Deploy**
5. Attendez 2 minutes → Vercel vous donne une URL comme : `digital-skills-academy.vercel.app`

✅ Votre formation est en ligne. Gratuit à vie sur Vercel.

### 1.4 Domaine personnalisé (optionnel, 800–1500 DZD/an)
- Achetez un domaine sur **Namecheap.com** (paiement carte ou PayPal)
- Exemple : `digitalskills.dz` ou `formationdz.com`
- Dans Vercel → Settings → Domains → ajoutez votre domaine

---

## ÉTAPE 2 — Système de Codes d'Accès

### Comment ça marche
- Un client paie → vous lui envoyez manuellement un code unique par WhatsApp/DM
- Il entre le code sur le site → il accède à la formation
- Le code est à usage unique (bloqué après utilisation sur un appareil)

### Codes actuels inclus dans App.js
```
DZSKILL2025
ATLAS-PRO
LEARN-DZ-01 à LEARN-DZ-05
ACADEMY-VIP
FORMATION01
FORMATION02
```

### Ajouter de nouveaux codes (quand vous vendez plus)
1. Ouvrez `src/App.js`
2. Trouvez le tableau `VALID_CODES`
3. Ajoutez vos nouveaux codes entre guillemets : `"MONCODE-06",`
4. Sauvegardez et re-uploadez sur GitHub → Vercel redéploie automatiquement

---

## ÉTAPE 3 — Recevoir les Paiements

### Option A — BaridiMob (recommandé pour l'Algérie)
- Partagez votre numéro CCP/BaridiMob
- Client paie → vous vérifiez → envoyez le code par WhatsApp

### Option B — Gumroad (paiement international)
1. Créez un compte sur **gumroad.com**
2. Nouveau produit → Product Type: **Digital Product**
3. Prix : mettez votre prix en USD (ex: 5$ ≈ 700 DZD)
4. Dans la description : mettez le lien de votre site Vercel
5. Dans "Content" : expliquez que le code sera envoyé après achat
6. Publiez → vous avez un lien de vente professionnel

### Option C — Instagram Direct
- Le plus simple pour commencer
- Post Instagram → "500 DZD → BaridiMob → code envoyé en DM"
- 0 setup requis

---

## ÉTAPE 4 — Stratégie de Prix et Vente

### Prix recommandés
| Offre | Prix | À qui |
|-------|------|-------|
| Formation complète (3 skills) | 1,500–2,500 DZD | Particuliers, étudiants |
| Formation 1 skill uniquement | 700–1,000 DZD | Budget limité |
| Accès groupe (5 codes) | 5,000 DZD | Petits groupes, associations |
| Licence école/centre de formation | 15,000–30,000 DZD | B2B |

### Message Instagram pour vendre
```
🎓 Formation Compétences Digitales 🇩🇿

✅ Graphisme (Canva → Illustrator)
✅ Social Media Management
✅ Montage Vidéo (CapCut → DaVinci)

Du DÉBUTANT au PRO — étape par étape.

💰 Gagnez 15,000–60,000 DZD/mois en freelance

Prix: 1,500 DZD seulement
Paiement: BaridiMob / CCP
Accès: immédiat après paiement

DM "FORMATION" pour commander 👇
```

### Quand poster
- Lundi et jeudi soir 20h–22h (meilleure portée en Algérie)
- Ajoutez des hashtags: #formationdz #freelancedz #digitalmarketing #graphismedz

---

## ÉTAPE 5 — Ajouter du Contenu (Mises à jour)

Pour mettre à jour les leçons ou en ajouter :
1. Ouvrez `src/Academy.jsx`
2. Trouvez le skill et le niveau concerné dans le tableau `skills`
3. Ajoutez une nouvelle leçon dans le tableau `lessons` en suivant la même structure :
```js
{
  title: "Titre de la leçon",
  steps: ["Étape 1...", "Étape 2..."],
  method: "La meilleure façon d'apprendre...",
  exercise: "Votre exercice pratique...",
  tip: "💡 Conseil pro..."
}
```
4. Re-uploadez le fichier sur GitHub → mise à jour automatique

---

## Structure des Fichiers

```
academy/
├── public/
│   └── index.html          (page HTML de base)
├── src/
│   ├── index.js            (point d'entrée React)
│   ├── App.js              (landing page + système de codes)
│   └── Academy.jsx         (tout le contenu de la formation)
├── package.json            (dépendances)
├── vercel.json             (config déploiement)
└── README.md               (ce guide)
```

---

## Support

Si vous bloquez sur une étape technique, la solution la plus rapide :
- Cherchez sur YouTube : "how to deploy react app to vercel" (tutoriel visuel, 10 min)
- Ou demandez à Claude de vous aider étape par étape

---

*Formation créée pour le marché algérien. Contenu mis à jour régulièrement.*
