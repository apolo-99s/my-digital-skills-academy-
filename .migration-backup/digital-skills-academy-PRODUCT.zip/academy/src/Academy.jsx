import { useState } from "react";

// ─────────────────────────────────────────────
// DATA — 3 skills, 4 levels each, full HOW-TO
// ─────────────────────────────────────────────
const skills = [
  // ════════════════════════════════════════════
  // SKILL 1: GRAPHIC DESIGN
  // ════════════════════════════════════════════
  {
    id: "design",
    icon: "🎨",
    color: "#7C3AED",
    accent: "#A78BFA",
    bg: "#0D0818",
    title: "Graphic Design",
    subtitle: "Visual Communication",
    tagline: "Turn ideas into visuals that sell",
    earning: "5,000 – 80,000 DZD / project",
    firstClient: "3–4 weeks",
    startTool: "Canva (free at canva.com)",
    levels: [
      {
        name: "Beginner",
        badge: "🌱",
        duration: "Weeks 1–4",
        goal: "Learn the 4 visual rules and create your first real designs in Canva",
        lessons: [
          {
            title: "How to Install & Set Up Canva",
            steps: [
              "Go to canva.com on your browser or download the Canva app on your phone from Google Play / App Store.",
              "Click 'Sign Up' and create a free account using your email or Google account.",
              "Once inside, you'll see a dashboard. At the top click 'Create a design'.",
              "You'll see size options: choose 'Instagram Post (Square)' for your first practice — it opens a blank 1080×1080px canvas.",
              "On the LEFT panel you have: Templates, Elements, Text, Background, Uploads. These are your main tools.",
              "On the TOP toolbar you see font controls, colors, position, and transparency when you click any element.",
              "Press Ctrl+Z to undo any mistake. Press Ctrl+D to duplicate any element.",
              "When done, click the purple 'Share' button top right → 'Download' → choose PNG for social media or PDF for print."
            ],
            method: "Open Canva right now and spend 20 minutes clicking every button in every panel. Don't design anything yet — just explore. Hover over each tool to read what it does. This exploration session is your real lesson.",
            exercise: "Create a plain Instagram post with just your name in big bold text and a colored background. Download it. This proves you know the full flow: open → create → edit → download.",
            tip: "💡 Canva Free gives you 250,000+ templates. You never need Canva Pro to start. Only upgrade after you have paying clients."
          },
          {
            title: "The 4 Design Rules (CARP) — With Examples",
            steps: [
              "CONTRAST: Make the most important thing the biggest or most different. If your title is white and background is light grey — nobody reads it. Fix it: make the background dark, text bright white. Or make the title 3× bigger than the subtitle.",
              "ALIGNMENT: Nothing sits randomly. Every text and image must align with something else. In Canva, turn on the grid: View → Show Rulers and Guides. Drag a guide line from the ruler and snap your elements to it.",
              "REPETITION: Use the same font, same color, same style for similar elements throughout. If your title is purple bold, ALL section titles must be purple bold — not one purple, one green, one italic.",
              "PROXIMITY: Group things that belong together, separate things that don't. A phone number and an email belong together — put them close. The logo and the contact info belong far apart.",
              "How to practice CARP: Open any Canva template. Click on each element and ask: 'Which of the 4 rules is this following?' Write your answer next to it.",
              "Open a real Algerian business flyer photo (search Google Images: 'flyer algérie restaurant'). Find 2 examples of each rule being followed or broken."
            ],
            method: "The fastest way to learn these rules is to BREAK them deliberately first, then fix them. Design a poster intentionally violating all 4 rules (random alignment, no contrast, mixed fonts, unrelated elements touching). Then redesign the same poster correctly. The comparison will make the rules unforgettable.",
            exercise: "Take any text — example: 'Restaurant El Baraka, Alger, Tel: 0555 123 456'. Design this as a business card in Canva TWICE: Version 1 = violate all 4 rules. Version 2 = follow all 4 rules perfectly. Screenshot both side by side.",
            tip: "💡 Professional designers break rules only AFTER they master them. You need 50+ designs before you earn the right to experiment."
          },
          {
            title: "Color Theory — How to Pick Colors That Work",
            steps: [
              "Go to coolors.co — this free tool generates harmonious color palettes in one click. Press the spacebar to generate a new palette. Lock colors you like by clicking the lock icon.",
              "Understand color emotions: Red = urgency, passion, food (Coca-Cola, McDonald's). Blue = trust, tech, health (Facebook, Visa, hospitals). Green = nature, organic, money. Yellow = happiness, youth, attention. Black = luxury, premium. White = clean, minimal, medical.",
              "The 60-30-10 rule: In any design, use your main color 60% (backgrounds, large areas), your secondary color 30% (titles, sections), your accent color 10% (buttons, highlights, important words only).",
              "How to extract colors from a photo: In Canva, click any image → 'Edit Photo' → 'Adjust' → use the eyedropper tool to pick a color from the image and apply it to text or shapes. This auto-creates harmony.",
              "How to check if colors work together: Go to color.adobe.com → select 'Complementary' or 'Analogous' from the dropdown → move the color wheel to your chosen base color → it shows you which colors work with it.",
              "NEVER use more than 3 colors in a single design when you're a beginner. 2 colors + 1 neutral (white, black, grey) is perfect."
            ],
            method: "Go to the Instagram pages of 5 successful Algerian brands (clothing, food, tech — anything). Screenshot their 3 most popular posts. For each post, identify: What is the main color? What emotion does it trigger? How many colors are used? Does it follow the 60-30-10 rule? Write your analysis in a notebook.",
            exercise: "Go to coolors.co, generate 5 different palettes. For each palette, name a type of Algerian business it would suit and explain WHY the colors match that business's emotion. Example: 'Palette 3 (dark blue + gold) suits a law firm because blue = trust and gold = premium.'",
            tip: "💡 The biggest beginner mistake is using too many colors. When in doubt, use black text on white, with ONE accent color. This always looks professional."
          },
          {
            title: "Typography — Choosing and Pairing Fonts",
            steps: [
              "Go to fonts.google.com — this is 100% free, 1,400+ fonts. Browse by category: Serif (has small feet = formal), Sans-serif (no feet = modern), Display (decorative = headlines only), Monospace (code-style).",
              "The pairing rule: ALWAYS use a maximum of 2 font families. Rule 1: One decorative/bold font for TITLES only. One clean readable font for BODY text. Example: 'Playfair Display' for titles + 'Lato' for body text.",
              "Font size hierarchy in any design: Main title = 36–72px. Subtitle = 18–28px. Body text = 14–16px. Fine print = 10–12px. Never break this hierarchy — the biggest text must always be the most important information.",
              "How to use fonts in Canva: Click any text → click the font name at top left → search by name → select. To change size: highlight text → change number in the size box next to the font name.",
              "Letter spacing (tracking): In Canva, click text → click '↔ Spacing' in the toolbar. For UPPERCASE titles: increase letter spacing to +50 to +150 for a premium look. For body text: keep it at 0.",
              "Line spacing (leading): Click text → Spacing → increase Line Height for readability. Body text needs 1.4–1.6× line height. Titles can be 1.0–1.2×.",
              "Fonts to avoid entirely as a beginner: Comic Sans (looks unprofessional), Papyrus (outdated), Times New Roman (too generic). These will immediately make your work look amateur."
            ],
            method: "Go to fontpair.co — this website shows pre-matched font combinations. Browse 20 pairings. For each one, ask yourself: 'What kind of business does this suit?' This trains your eye faster than any theory.",
            exercise: "In Canva, design the same business card 4 times using 4 different font combinations: 1) Classic (Playfair + Lato), 2) Modern (Montserrat + Open Sans), 3) Creative (Pacifico + Roboto), 4) Premium (Cormorant Garamond + Jost). Compare them and write which you'd choose for a restaurant, a law firm, and a clothing boutique.",
            tip: "💡 In Arabic design: use 'Cairo', 'Tajawal', or 'Noto Kufi Arabic' — these are professional Arabic Google Fonts that are free and look modern."
          },
          {
            title: "How to Design a Real Logo from Zero",
            steps: [
              "Step 1 — Brief yourself: Before touching Canva, answer these questions on paper: What is the business name? What does it do? Who are the customers (age, gender, style)? Name 3 adjectives that describe the brand (serious, playful, premium, traditional, modern...)?",
              "Step 2 — Research: Google 'logo + [the industry]'. Look at 10 competitor logos. Write down: What colors do they all use? What style (text only? icon + text? symbol only?). What will make YOUR logo different?",
              "Step 3 — Sketch on paper: Draw 10 rough logo concepts on paper in 15 minutes. They can be terrible — that's the point. No erasing allowed. Sketch fast. Circle your 2 favorites.",
              "Step 4 — Digitize in Canva: Open Canva → Create a design → Custom size: 500×500px. Search 'Elements' for icons related to the business. Combine icon + business name text. Try 3 color variations.",
              "Step 5 — The logo must work in black and white: A real logo works without color. Click your logo → Download → select Black & White from filters. If it still looks good, it's a real logo. If it falls apart, the design is too dependent on color.",
              "Step 6 — Deliver these files to any client: PNG with transparent background (for use anywhere), PNG on white background, PNG on black background, PDF (for print). In Canva: Download → PNG → check 'Transparent background' (requires Canva Pro — workaround: use remove.bg free website to remove background)."
            ],
            method: "The fastest way to learn logo design is to RE-CREATE existing logos from scratch. Take the logo of any Algerian telecom (Djezzy, Ooredoo, Algérie Telecom) and try to rebuild it in Canva or using free tool Canva → Elements → search the shape. You'll learn more from this than from any tutorial.",
            exercise: "Design a complete logo for this fictional business: 'ATLAS', a premium Algerian coffee brand targeting young professionals in Alger. Deliver: 3 color variations, 1 black version, 1 white version. Write 3 sentences explaining why you made each design choice.",
            tip: "💡 The most professional logos are the simplest. Apple is an apple. Nike is a swoosh. Resist the urge to add more elements when something feels 'too simple'."
          }
        ]
      },
      {
        name: "Intermediate",
        badge: "⚡",
        duration: "Weeks 5–10",
        goal: "Move from Canva to Photoshop, build real client projects",
        lessons: [
          {
            title: "How to Install & Learn Photoshop (or Free Alternative)",
            steps: [
              "PAID option: Adobe Photoshop is available at adobe.com — 7-day free trial. After trial: ~1,200 DZD/month (student discount available).",
              "FREE alternative (same interface): Go to photopea.com — this runs in your browser, looks 99% identical to Photoshop, completely free, no download needed. Use this to start.",
              "The Photoshop/Photopea interface: Left panel = Tools (move, crop, brush, eraser, text). Right panel = Layers (the most important concept). Top bar = Options for the selected tool. Middle = Your canvas.",
              "LAYERS are everything: Think of layers like transparent sheets stacked on top of each other. Each element (photo, text, shape) lives on its own layer. You can show/hide each layer, reorder them, and edit them without affecting others.",
              "How to open a photo: File → Open → select your image. It appears as a locked 'Background' layer. Double-click it and press OK to unlock it for editing.",
              "How to remove a background: Select the 'Magic Wand' tool from the left panel → click on the background area → press Delete. For complex backgrounds (hair, fur): use Select → Subject → then Select → Modify → Expand by 2px → press Delete.",
              "How to add text: Press T on keyboard (text tool) → click on canvas → type → select the text layer → change font/size/color in the top bar.",
              "How to save: File → Export → Export As → choose PNG (for transparent background, keep 'Transparency' checked) or JPEG (for photos). NEVER use 'Save As' for JPEG quality — always use Export."
            ],
            method: "On Photopea.com: open any photo of a product (a bottle, a phone, a shoe). Remove the background. Place the product on a new colored background. Add the text 'NEW ARRIVAL' above it and the product price below it. This simulates a real social media ad — and you've just learned 70% of what clients will pay you for.",
            exercise: "Find a photo of any Algerian traditional product (tajine, couscous, handicraft). Remove the background in Photopea. Place it on a clean white background. Add a professional price tag, a product name in French, and a subtle shadow under the product. Download as PNG.",
            tip: "💡 The shadow trick: In Photopea, after placing your product on a new background, right-click the product layer → 'Blending Options' → check 'Drop Shadow' → set opacity 40%, distance 10px, blur 20px. This makes flat objects look real and grounded."
          },
          {
            title: "How to Do Product Photography with Just Your Phone",
            steps: [
              "Light source setup: Sit your product near a WINDOW (not in direct sunlight — diffused window light is softer). Position the product so the window is to the LEFT or RIGHT, not behind you or behind the product.",
              "Background setup: Use a plain white A3 paper sheet, a white cardboard, or a clean white wall. Tape it so it curves (no visible corner/fold behind the product). This is called an infinity sweep.",
              "Camera settings on phone: Tap the product on your screen to focus. Lock focus and exposure by holding your finger on the subject (most Android/iPhone cameras). This stops the camera from refocusing mid-shoot.",
              "Rule of thirds: In your phone camera settings, enable 'Grid'. This shows a 3×3 grid on your screen. Place the product at one of the 4 grid intersection points, not dead center. This creates a more interesting composition.",
              "Take 3 types of shots for every product: Hero shot (product centered, clean background — the main image), Detail shot (extreme close-up of texture, label, or detail), Lifestyle shot (product in a real context — coffee cup on a wooden desk with a book).",
              "Editing the phone photo: Use Snapseed (free app). Open photo → Tools → selective → tap the product → increase Brightness slightly → Tools → Tune Image → reduce Highlights (removes harsh bright spots) → increase Shadows (opens dark areas) → export."
            ],
            method: "Set up a phone product shoot TODAY with any object at home (a perfume bottle, a food container, a book). Take 15 photos varying only the angle (top-down, 45°, eye-level, close-up). Edit your 3 best in Snapseed. Compare them. You'll immediately see how angle and light change everything.",
            exercise: "For a fictional Algerian honey brand called 'Miel du Hoggar': shoot 5 product photos of any honey jar (or any similar product you have) using the techniques above. Edit them to feel premium and warm. These become your first portfolio photography pieces.",
            tip: "💡 A 20 DZD sheet of white paper is better than any expensive studio backdrop for 90% of small product shots. Professional photographers call this 'keeping it clean'."
          },
          {
            title: "How to Design a Complete Social Media Brand Kit",
            steps: [
              "A Brand Kit is a set of templates that keeps a brand visually consistent. It includes: Post templates (feed posts), Story templates, Highlight cover icons, Profile photo frame.",
              "Step 1 in Canva: Go to 'Brand Kit' in the left sidebar (free version has limited features — use manual approach). Create a new folder called 'Client Name — Brand Kit'.",
              "Step 2 — Define the system: Open a new Canva doc (any size). Create 5 rectangles showing: Primary color (hex code), Secondary color, Accent color, Neutral (white/black/grey), Background color. This is your color palette card.",
              "Step 3 — Create the Post Templates: Create an Instagram Post (1080×1080). Build your first layout. Once happy, duplicate it (Ctrl+D in Canva). On the duplicate, change ONLY the content (text, image) but keep the layout, fonts, and colors identical. This is how you create a template.",
              "Step 4 — Create at least 6 post types: Quote post, Product showcase post, Tip/educational post, Promotional offer post, Behind the scenes post, Testimonial/review post.",
              "Step 5 — Create Story templates (1080×1920): These are taller versions. Keep the same fonts and colors. Add interactive elements: poll sticker area, question box area, swipe-up call to action at the bottom.",
              "Step 6 — Package delivery: Export all templates as PNG images AND share the Canva file link with the client so they can edit text themselves."
            ],
            method: "Go to Instagram and find any successful Algerian brand (clothing, food, service). Screenshot 9 of their posts. Open them side by side. Count: How many different fonts? How many colors? Is there a visual pattern to their layout? Most brands that look professional use IDENTICAL layouts — just swap the image and text. Your job is to BUILD that system.",
            exercise: "Create a complete 6-template brand kit in Canva for a fictional brand: 'DZ Organic' — an organic food brand based in Algiers targeting health-conscious young women. Deliver: color palette card, 6 post templates, 2 story templates. All must look like they belong to the same brand.",
            tip: "💡 When you deliver a brand kit to a client, ALSO deliver a 1-page PDF document showing them: what fonts to use, what colors, what NOT to do. This prevents them from ruining the brand you built for them."
          },
          {
            title: "How to Build a Portfolio That Gets Clients",
            steps: [
              "Rule: You need 10 portfolio pieces BEFORE you approach a single client. Not 3. Not 5. Ten. And they must look like they were made for real businesses, not for school projects.",
              "Step 1 — Create fictional clients: Pick 5 real types of businesses in your city (a restaurant, a clothing boutique, a pharmacy, a delivery service, a café). Invent brand names. These are your 'case studies'.",
              "Step 2 — For each fictional client, create: 1 logo + 1 business card + 3 social media posts. That's 15 pieces from 5 clients = more than enough for a strong portfolio.",
              "Step 3 — Create a Behance account (behance.net — free, industry standard). For each project, create a 'Project' page. The layout: Cover image (most impressive visual) → Brief (what was the goal?) → Process (show your sketches or early drafts) → Final result (all deliverables).",
              "Step 4 — The mockup trick: A real designer never shows a logo on a plain white background. They show it on a business card, a t-shirt, a coffee cup, a billboard. Go to freepik.com or mockupworld.co — search 'free mockups'. Download PSD files, open in Photopea, paste your logo onto the mockup. Instant professional presentation.",
              "Step 5 — Your Instagram becomes a portfolio: Create a separate Instagram account for your design work. Post 1 project per day for 10 days. Use hashtags: #graphicdesigndz #designalgerie #logodesign #brandidentity.",
              "Step 6 — Collect testimonials: After each free project (yes, your first 3 should be free for local businesses), ask the owner to write 2 sentences about working with you. These testimonials go on your portfolio. Nothing sells better than a real business owner saying 'he designed our logo and our sales increased'."
            ],
            method: "Do this right now: Open Behance, create your account, and complete your profile photo, bio ('Graphic Designer based in Alger, specializing in brand identity for local businesses'), and the link to your Instagram. An incomplete profile makes you look unprofessional before anyone even sees your work.",
            exercise: "Create your first Behance case study for the 'ATLAS Coffee' logo you made in the Beginner level. Include: 1 cover image, the logo in 3 color versions, a business card mockup, and 3 sentences explaining your design decisions. Publish it publicly.",
            tip: "💡 A portfolio with 10 well-presented fictional projects beats a portfolio with 3 real projects shown poorly. Presentation IS the skill."
          }
        ]
      },
      {
        name: "Advanced",
        badge: "🔥",
        duration: "Weeks 11–20",
        goal: "Master Adobe Illustrator, deliver full brand identities, set professional rates",
        lessons: [
          {
            title: "How to Learn Adobe Illustrator (Vectors)",
            steps: [
              "Download Inkscape (inkscape.org) — 100% free, professional, very similar to Illustrator. Or use 7-day free trial of Adobe Illustrator.",
              "The key difference from Photoshop: Illustrator creates VECTOR graphics (math-based shapes). A vector logo can be printed on a business card or a 10-meter billboard with ZERO quality loss. A Photoshop JPEG logo becomes blurry when enlarged. This is why all logos must be vectors.",
              "The Pen Tool (P): This is the most important tool in Illustrator. It creates paths (lines and curves). Click to create a straight corner point. Click and DRAG to create a smooth curve point. Click the first point again to close the shape. Practice drawing the outline of a simple leaf shape — just the outline.",
              "How to use the Pen Tool to trace a logo: Open any image → File → Place to import it. Lock that layer (click the lock icon in the Layers panel). Create a new layer above it. Use the Pen Tool to trace every shape of the logo on the new layer. Delete the original image layer. You now have a clean vector version.",
              "Pathfinder operations (Window → Pathfinder): Unite (merge 2 shapes into 1), Minus Front (subtract top shape from bottom shape), Intersect (keep only overlapping area). These 3 operations create 90% of all logo shapes.",
              "Colors in Illustrator: Select a shape → click the Fill color square at the bottom left → enter hex code. For gradients: click the Gradient tool (G) → drag across the shape."
            ],
            method: "The pen tool exercise: print any simple logo (3–5 shapes maximum). Trace every single shape using ONLY the pen tool in Inkscape. No cheating with shape tools yet. Do this for 5 logos over one week. Your pen tool control will be professional level.",
            exercise: "In Inkscape/Illustrator, recreate the Ooredoo or Djezzy logo from scratch using only the Pen Tool and Pathfinder operations. Compare your result to the original. Note where the shapes don't match perfectly and correct them.",
            tip: "💡 All professional logos are vectors. If a client shows you their logo as a JPEG and asks you to use it, immediately offer to redraw it as a vector (charge 3,000–8,000 DZD for this service alone — it takes 30–90 minutes)."
          },
          {
            title: "How to Create a Full Brand Identity System",
            steps: [
              "A Brand Identity is NOT just a logo. It's a complete visual language. Deliverables for a full brand identity project: Primary logo, Secondary logo (horizontal version), Icon/Symbol only, Color palette with hex codes, Typography guide (2 fonts with usage rules), Business card (front + back), Letterhead template, Social media templates (3 post types), Brand guideline PDF (the instruction manual).",
              "Step 1 — Discovery session with client: Meet in person or on WhatsApp call. Ask: Who are your customers? Who are your 3 main competitors? What 3 words describe your brand? What brands do you admire (not in your industry)? What is your budget and timeline?",
              "Step 2 — Moodboard: Go to Pinterest. Create a board. Pin 20–30 images that match the brand's desired feeling (not logos — general images, textures, photos, colors). Share this with the client BEFORE designing anything. Get approval on the direction.",
              "Step 3 — Logo design (3 concepts): Create 3 very different logo directions. Present them on mockups (business card, Instagram post, tote bag). Explain the rationale for each. Let the client choose 1 direction for refinement.",
              "Step 4 — System development: Once the logo is approved, build all other elements. Everything must feel like it came from the same visual world — same roundness of corners, same weight of lines, same color mood.",
              "Step 5 — Brand Guideline PDF: This is a document (8–15 pages) showing: How to use the logo correctly (clear space, minimum size), Wrong uses of the logo (stretched, wrong colors, on busy backgrounds), Color codes (hex, CMYK, RGB, Pantone), Typography rules, Photography style, Tone of voice.",
              "Pricing for full brand identity in Algeria: 35,000–120,000 DZD depending on your experience and client size. Never go below 25,000 DZD for a full system."
            ],
            method: "Before charging for a full identity, complete one full project for a real local business for free or at a heavy discount. Post the ENTIRE process on social media — the brief, the moodboard, the logo sketches, the final result. This one documented project will bring you 3–5 paying clients through referral and visibility.",
            exercise: "Create a full brand identity for 'Baya', a young Algerian women's clothing boutique. Deliver: Logo (3 versions), Color palette, Typography guide, Business card mockup, 3 Instagram templates, 5-page mini brand guide PDF. Document the entire process.",
            tip: "💡 The Brand Guideline PDF is what separates a freelancer from an agency. A freelancer delivers a logo file. An agency delivers a complete brand system with instructions. The second charges 5× more."
          },
          {
            title: "How to Set Prices and Handle Clients Professionally",
            steps: [
              "Pricing formula: Estimate time in hours × your hourly rate + 20% complexity buffer. Start your hourly rate at 800–1,200 DZD/hour. A logo that takes 8 hours = 6,400–9,600 DZD minimum.",
              "Standard prices for Algeria (intermediate level): Logo design 8,000–20,000 DZD. Brand identity full system 35,000–80,000 DZD. Social media monthly management 15,000–35,000 DZD. Business card design 3,000–6,000 DZD. Flyer/poster 4,000–8,000 DZD.",
              "Payment terms: ALWAYS take 50% upfront before starting any work. Say exactly this: 'Mon processus de travail inclut 50% d'avance au démarrage et 50% à la livraison des fichiers finaux.' If they refuse the deposit, do NOT start the work — clients who won't pay upfront rarely pay at the end.",
              "Revisions policy: Include 2 rounds of revisions in your price. State this in writing at the start. If the client wants more, charge 1,500–3,000 DZD per additional revision round. This is standard globally.",
              "How to write a proposal (devis): Client name + project description + list of deliverables + timeline + price breakdown + payment terms + your signature. Send it via PDF. Keep a template saved and just update the details each time.",
              "How to handle price negotiation: If they say 'c'est trop cher': First, do NOT immediately lower the price. Ask: 'Quel est votre budget?' If their budget is lower but reasonable, offer to reduce the scope (fewer deliverables) instead of reducing the price. If the budget is insultingly low, politely decline and move on."
            ],
            method: "Create your pricing menu today as a PDF in Canva. List every service you offer with price ranges. Don't publish it publicly yet — but having it written makes you 10× more confident when a client asks 'combien ça coûte?' Having a document to share also signals professionalism.",
            exercise: "Write a full proposal PDF for a fictional logo + brand identity project for a client called 'Pharmacie Al Shifa, Oran'. Include all sections: project description, deliverables list, 3-week timeline, pricing breakdown, payment terms. Design it professionally in Canva.",
            tip: "💡 Your confidence in saying your price out loud without hesitating is a skill that needs practice. Say your prices into a mirror or to a friend 10 times until you can state them calmly and without apology."
          }
        ]
      },
      {
        name: "Master",
        badge: "👑",
        duration: "Month 6+",
        goal: "Run a design agency, hire juniors, work with advertising agencies",
        lessons: [
          {
            title: "How to Transition From Freelancer to Agency",
            steps: [
              "The moment to start an agency: When you consistently have more work than you can handle alone AND you're turning down projects because of time. Not before.",
              "Step 1 — Find your first collaborator: Your best student from any workshop you taught, or a talented designer you met online. Start with a project-based collaboration (pay them per project, no salary commitment yet).",
              "Step 2 — Define roles clearly: You handle: client acquisition, proposals, project management, final quality check. They handle: execution (designing under your direction). You charge the client the full rate, pay your collaborator 40–50% of the project fee.",
              "Step 3 — Create your agency brand: Your freelance name was personal. Your agency needs a brand name, a logo, an Instagram, a simple website (use Carrd.co — free, beautiful, 30 minutes to build).",
              "Step 4 — Develop service packages: Stop pricing per project. Create monthly retainer packages: Starter Pack (12 posts/month + 1 logo/month = 25,000 DZD/month), Growth Pack (20 posts + full brand kit + ads design = 55,000 DZD/month), Premium Pack (unlimited design requests = 100,000+ DZD/month).",
              "Step 5 — Target agencies not individuals: Advertising agencies and marketing firms need design subcontractors constantly. One agency client can give you the equivalent of 10 individual clients. Approach the 5 biggest advertising agencies in your city. Offer to be their design partner on overflow work."
            ],
            method: "Do a 'fake pitch': find a local business with clearly bad design (social media, logo, signage). Create an unsolicited redesign — redo their logo and 3 Instagram posts — and send it to them with a message: 'I redesigned your brand visual for free to show you what's possible. If you'd like to apply this across your full presence, I'd love to discuss.' This approach has converted into paying clients at an extremely high rate.",
            exercise: "Identify 3 real Algerian businesses with weak visual identities online. Create unsolicited redesigns for ONE of them (logo + 2 posts). Write a professional cold outreach message to send them. Whether or not they respond, publish the redesign on your portfolio as a 'concept' project.",
            tip: "💡 The fastest growth strategy for an Algerian design agency: specialize in ONE industry. Become 'the agency for restaurants in Alger' or 'the agency for real estate in Oran'. Specialists always charge more than generalists."
          }
        ]
      }
    ]
  },

  // ════════════════════════════════════════════
  // SKILL 2: SOCIAL MEDIA MANAGEMENT
  // ════════════════════════════════════════════
  {
    id: "smm",
    icon: "📱",
    color: "#059669",
    accent: "#34D399",
    bg: "#021A12",
    title: "Social Media Management",
    subtitle: "Digital Marketing",
    tagline: "Help businesses grow their audience & sell online",
    earning: "15,000 – 60,000 DZD / month per client",
    firstClient: "2–3 weeks",
    startTool: "Meta Business Suite (free) + Canva",
    levels: [
      {
        name: "Beginner",
        badge: "🌱",
        duration: "Weeks 1–3",
        goal: "Understand how algorithms work and create your first content strategy",
        lessons: [
          {
            title: "How to Set Up a Professional Instagram & Facebook Business Account",
            steps: [
              "Instagram: Go to your Instagram profile → tap the 3 lines top right → Settings → Account → Switch to Professional Account → select 'Business' → choose category (Restaurant, Local Business, etc.) → connect to a Facebook Page.",
              "Facebook: Go to facebook.com/pages/create → Business or Brand → enter name and category → add profile photo (logo, 180×180px) → add cover photo (820×312px) → click 'Edit Page Info' and fill in EVERY field: address, phone, website, hours, description.",
              "Meta Business Suite: Go to business.facebook.com → click 'Create Account' → connect your Facebook Page and Instagram → this single dashboard now manages BOTH platforms. Use it for: scheduling posts, reading messages, checking analytics.",
              "Connect WhatsApp Business: Download WhatsApp Business app → use the business phone number → link it in Facebook Page settings under 'WhatsApp'. Now all Facebook and Instagram ads can have a WhatsApp CTA — this is crucial for Algeria where WhatsApp is the primary contact method.",
              "Complete the profile 100%: Platforms algorithmically reward complete profiles with more reach. Add: profile photo, bio (80 characters max, include keywords), link in bio (use Linktree.com for multiple links — free), location, contact button.",
              "Create a content folder: On your phone, create a new folder called 'Client Content'. Inside: subfolders for Photos, Videos, Captions, Approved Posts. Professional SMMs never search through their camera roll for content."
            ],
            method: "Set up a practice 'test account' on Instagram using a new email address. Call it something like 'DZFoodTestAccount'. This is your practice sandbox where you'll test every strategy before applying it to a real client. Every lesson from now on, test it on this account first.",
            exercise: "Set up a complete business profile for a fictional local restaurant on both Instagram and Facebook. Connect both to Meta Business Suite. Fill in every single field. Take a screenshot of the 100% complete profile as proof.",
            tip: "💡 The most important link on Instagram is the 'link in bio'. Use linktr.ee to create a free page with multiple buttons: WhatsApp link, Facebook, Menu PDF, Google Maps. Update this link every time you run a promotion."
          },
          {
            title: "How the Instagram Algorithm Works in 2025 — Step by Step",
            steps: [
              "The algorithm has ONE job: keep people on the app as long as possible. It does this by showing each user content they are most likely to engage with. Your job is to trigger that engagement.",
              "The 5 signals the algorithm measures (in order of importance): 1. SAVES — the most powerful signal. Someone saves your post = they think it's worth keeping. Make every post 'saveable' (useful tips, checklists, infographics). 2. SHARES — someone sends your post to a friend. This expands your reach beyond followers. 3. COMMENTS — real conversations. 2-word comments barely count. A 10-word+ comment is a strong signal. 4. LIKES — weakest engagement signal but still counts. 5. WATCH TIME (for Reels) — how long people watch your video.",
              "How to engineer saves: End every educational post with 'Sauvegardez ce post pour y revenir ✅'. Posts with tips, numbered lists, step-by-step guides, or recipes get saved more than opinion posts.",
              "How to engineer comments: Ask a genuine question at the end of every caption. Not 'What do you think?' (too vague) but 'Entre tajine et couscous, vous choisissez quoi ce week-end? 👇' (specific, easy to answer, culturally relevant).",
              "How to read Instagram Insights: Go to any post → tap 'View Insights' below it. You'll see: Accounts reached (how many unique people saw it), Impressions (total times it was shown), Interactions (all engagement combined). For Reels: also see Average watch time and Completion rate. Track these numbers weekly in a Google Sheet.",
              "Optimal posting times for Algeria: Based on when Algerians are most active on phones. Research shows: 12:00–13:30 (lunch break), 18:00–20:00 (after work), 21:00–23:00 (evening relaxation). Test your specific audience by checking 'Most Active Times' in Instagram Insights → Audience."
            ],
            method: "Do the Algorithm Audit: Go to your personal Instagram (or the practice account). Look at the last 20 posts from accounts you follow that got high engagement. For each one, identify: Was there a question in the caption? Did it have a 'save this' CTA? Was it informative, funny, or controversial (the 3 emotions that drive shares)? Write what pattern you notice. This analysis is more valuable than 10 hours of theory.",
            exercise: "On your practice test account: publish 3 posts over 3 days. Post 1: a simple photo with no CTA. Post 2: an informative carousel with 'Sauvegardez ✅' at the end. Post 3: a photo with a direct easy question. After 48 hours, compare the Insights numbers for all 3. Document what you found.",
            tip: "💡 Instagram actively suppresses posts that include external links in the CAPTION (YouTube, website, etc.). Never put links in captions. Always say 'lien en bio' and put the link in your profile."
          },
          {
            title: "How to Create a Content Strategy from Zero",
            steps: [
              "Step 1 — Define the audience persona: Write a paragraph describing the EXACT person who should see this content. Example: 'Fatima, 28 ans, Alger, travaille comme comptable, suit des pages de mode et de cuisine, utilise Instagram et Facebook le soir, cherche des produits locaux de qualité, budget moyen-haut.' Everything you post should be targeted at Fatima specifically.",
              "Step 2 — Define 4 Content Pillars: These are the 4 main topics the brand will post about. Every single post must fit into one of these pillars. Example for a clothing boutique: Pillar 1 = New arrivals and products, Pillar 2 = Style tips and outfit ideas, Pillar 3 = Behind the scenes (sourcing, packaging, team), Pillar 4 = Customer stories and testimonials.",
              "Step 3 — Define content formats: For each pillar, decide which formats you'll use. Pillar 1 (products) → Photos + short Reels. Pillar 2 (tips) → Carousel posts (multi-slide). Pillar 3 (behind scenes) → Stories + casual Reels. Pillar 4 (testimonials) → Story screenshots + graphic posts.",
              "Step 4 — Create a posting schedule: Start with 4 posts per week for Instagram + 3 for Facebook. Example week: Monday → Product post, Wednesday → Tip carousel, Friday → Behind the scenes Reel, Sunday → Customer story. Consistency beats frequency.",
              "Step 5 — Hashtag strategy: For each post, use 8–15 hashtags. Mix: 3 large (1M+ posts: #mode #food #algerie), 5 medium (10K–500K: #modedz #cuisinealgérienne), 5 small and niche (under 10K: #boutiquealgéroise #livraisonalger). Small hashtags have less competition = your post can rank #1 in that hashtag.",
              "Step 6 — The caption formula: Line 1 = HOOK (makes them stop scrolling). Lines 2–5 = VALUE (the actual content). Last line = CALL TO ACTION. Always break text into short paragraphs with line breaks. Long unbroken paragraphs are never read on mobile."
            ],
            method: "Content strategy shortcut: Go to the Instagram of the 3 most successful businesses in your target niche in Algeria. Look at their top 12 posts (the ones with most likes + comments). Write down exactly what FORMAT and TOPIC each one used. This tells you what the Algerian audience in that niche already responds to. Build your pillars around what's already working.",
            exercise: "Create a complete written content strategy document for a fictional Algerian online clothing brand. Must include: 1 audience persona (full paragraph), 4 content pillars with descriptions, 1-month posting calendar (showing 16 posts with day, pillar, format, and caption topic for each), hashtag lists for each pillar.",
            tip: "💡 In Algeria, content in DARIJA (Algerian Arabic) consistently gets 2–3× more comments than content in French on the same topic. Use Darija for relatable, funny, or emotional content. Use French for professional or informational content."
          },
          {
            title: "How to Write Captions That Stop the Scroll",
            steps: [
              "The HOOK is the first 125 characters visible before 'See More'. If the hook fails, nobody reads the rest. The 5 most powerful hook types: Question ('Vous faites encore cette erreur avec votre routine matinale?'), Bold statement ('La majorité des restaurants algériens perdent des clients à cause d'une seule chose.'), Number ('5 astuces pour doubler vos ventes en ligne en 30 jours.'), Controversy ('On n'est pas d'accord avec la plupart des experts sur ce sujet.'), Story ('Il y a 2 ans, notre boutique était au bord de la fermeture...').",
              "The VALUE section (middle of caption): Deliver on the promise of the hook. If you asked a question, answer it. If you said '5 tips', list them with numbers and line breaks. Each point needs to genuinely help, entertain, or inform. Never write filler content.",
              "The CTA (Call to Action): End with ONE specific action. 'Dites-nous en commentaire' → drives comments. 'Partagez avec quelqu'un qui en a besoin' → drives shares. 'Sauvegardez pour ne pas oublier' → drives saves. 'Lien en bio pour commander' → drives traffic. Never use more than one CTA per post — it confuses people.",
              "Emojis: Use them as visual bullets and line separators, not decoration. Example: '✅ Astuce 1: ...' is easier to read than a plain text list. Limit to 2–3 types of emoji per post for visual consistency.",
              "Language mixing (code-switching): Highly effective in Algeria. Mix French and Darija in the same caption. Example: 'Ce produit 💯 chkhitar barakAllah fikum 🙏 — livraison gratuite pour toute commande +3000 DZD.' This feels authentic and local.",
              "Caption length: No universal rule. Short captions (1–3 lines) work for strong visual posts. Long captions (200–300 words) work for educational and storytelling posts. Medium captions (5–8 lines) for product posts. Match length to the content purpose."
            ],
            method: "Swipe file exercise: Create a notes document called 'Great Captions'. For the next 7 days, whenever you see a caption that makes YOU stop scrolling or that you want to comment on — copy it into the document. After 7 days, you'll have 20+ examples. Analyze what they have in common. These patterns become your writing formula.",
            exercise: "Write 10 different captions for the same product: a traditional Algerian handmade candle. Each caption must use a different hook type. Write 5 in French, 5 mixing Darija and French. Include hashtags and CTA for each. Then pick your 3 strongest ones and explain why they'd perform best.",
            tip: "💡 The 'Save this post' trick: Carousel posts (multiple slides) that end with a summary or checklist get saved up to 5× more than single-image posts. Always offer something worth saving — a list, a step-by-step, a comparison."
          }
        ]
      },
      {
        name: "Intermediate",
        badge: "⚡",
        duration: "Weeks 4–9",
        goal: "Create Reels, run ads, manage your first real client",
        lessons: [
          {
            title: "How to Create a Reel That Gets Real Views",
            steps: [
              "The 0.5-second rule: The first visual frame must be interesting enough that someone stops mid-scroll. How to achieve this: start with text already on screen, start with an action already happening, start at the most interesting visual moment of your video. NEVER start with a logo or intro screen.",
              "Script a Reel like this: Hook (0–2 seconds): visual surprise or bold text. Setup (2–8 seconds): context or problem. Payoff (8–20 seconds): the valuable or entertaining content. CTA (last 2 seconds): text overlay 'Follow for more' or 'Share this'.",
              "Filming on phone for Reels: Use your phone VERTICALLY (9:16). Film in a well-lit area (window light or ring light). Use the back camera — it's sharper than the front. For speaking to camera: look at the LENS not the screen. Film each shot 3× — use the best take.",
              "Editing in CapCut (free): Download CapCut from app store. New Project → add your clips. On the timeline, tap a clip to see: Split (cut it), Delete, Speed (for slow-mo: 0.5×, for fast: 2×). Add text: tap 'Text' → 'Add Text' → type → select font and color → drag on screen to position. Add music: tap 'Audio' → 'Sounds' → search trending songs. Export: tap the arrow top right → select 1080p → save to phone.",
              "The Trending Audio trick: Go to Instagram, tap the Reels tab, find a Reel with a 'trending arrow' (↗) next to the audio name. This means that audio is being used in many Reels — the algorithm is currently pushing it. Use this audio in your next Reel to get extra push. Note: the audio must make sense with your content.",
              "Subtitles are mandatory: 60% of people watch Reels without sound. In CapCut: tap 'Text' → 'Auto Captions' → select your language → it automatically transcribes. Review and correct any errors. Style them: bold, white text with black outline, positioned in the center-bottom of screen."
            ],
            method: "The fastest way to understand what makes a Reel viral: Go to Instagram Reels tab. Spend 20 minutes consciously watching (not for entertainment — for study). For every Reel that makes you watch past 5 seconds, pause and ask: What was the hook? What kept me watching? What was the pacing? Write your findings. This 20-minute session teaches more than 5 hours of reading about Reels.",
            exercise: "Film and edit 3 Reels this week: 1) A 'Before/After' Reel showing a transformation (design, food preparation, cleaning — anything visual). 2) A '3 Tips' educational Reel in your niche. 3) A 'Behind the scenes' Reel showing how something is made or prepared. Post all 3 to your practice account and compare views after 48 hours.",
            tip: "💡 Post your best Reel at 7:00 PM Algeria time. This is when engagement rates are highest. Use Instagram's scheduling feature (Meta Business Suite) to schedule it in advance so you don't forget."
          },
          {
            title: "How to Run Facebook and Instagram Ads on a Small Budget",
            steps: [
              "Go to business.facebook.com → Ads Manager → Create Campaign. You'll see the campaign structure: Campaign (your goal) → Ad Set (your audience) → Ad (your creative). Each level is separate.",
              "Choose your campaign objective: For local Algerian businesses, the most useful objectives are: Messages (people click and message you on WhatsApp — best for most Algerian businesses), Traffic (send people to a website or link), Engagement (boost a post's likes and comments), Video Views (get more people to watch your video).",
              "Audience targeting for Algeria: In the Ad Set level → Audience → Location: type 'Algeria' → you can narrow by wilaya (city). Age range: set based on your product (clothing boutique = 18–35, pharmacy = 25–55). Interests: type interests related to your product. Behaviors: if you have an app or website, you can target people who visited. Keep audience size between 200,000 and 1,500,000 — too small = expensive, too large = unfocused.",
              "Budget: Start with 200–500 DZD/day. Don't start with 50 DZD/day — too low for Facebook's algorithm to learn and optimize. Run for minimum 5 days before judging results. Total test budget: 1,000–2,500 DZD for a first campaign.",
              "Creating the Ad creative: Use a vertical video (9:16) or square image (1:1). Add text overlay on the image/video (the hook). Keep the primary text caption under 125 characters. Add a WhatsApp link as the CTA button. Test 2 different creatives in the same ad set — Facebook will automatically show the better-performing one more.",
              "How to read the results: Key metrics to track: Cost Per Result (how much does each lead/message/click cost?), Reach (how many unique people saw it?), Frequency (how many times average person saw it — keep below 3, above 3 means same people are seeing it too often and getting annoyed). If Cost Per Result is too high: change the creative or narrow the audience."
            ],
            method: "Run your first ad with just 500 DZD on ANY simple campaign — even just to boost a post you already made. The goal is not results — it's to navigate the entire Ads Manager interface from start to finish. You'll make mistakes and learn more from doing this once than from 10 YouTube tutorials.",
            exercise: "Create a complete mock ad campaign in Ads Manager (you can set it up without running it by keeping it in 'Draft' status): Campaign objective = Messages (WhatsApp). Audience = Women 20–35 in Algiers interested in fashion. Budget = 300 DZD/day for 7 days. Write 2 different ad copies (captions) and describe 2 different creative images you'd use. Calculate the projected reach and estimate cost per message.",
            tip: "💡 The best-performing Facebook Ads in Algeria always include WhatsApp as the CTA. Algerians trust WhatsApp for business communication more than websites or emails. A 'Send WhatsApp Message' button converts 3–5× better than 'Visit Website' in the Algerian market."
          },
          {
            title: "How to Build and Manage a Monthly Content Calendar",
            steps: [
              "Open Google Sheets. Create columns: Date | Day | Platform | Pillar | Content Type | Caption (draft) | Visual Description | Status (draft/ready/posted) | Results (fill after posting).",
              "Plan one month at a time, 2 weeks in advance. Sit down every 2 weeks for 90 minutes and fill in the next 2 weeks of calendar. This session is sacred — do not skip it.",
              "Batch creation workflow: Dedicate 1 full day per week to content creation for the following week. Monday = writing day (write all captions). Tuesday = design day (create all visuals in Canva). Wednesday = film day (record all videos/Reels). Thursday = schedule everything in Meta Business Suite. Friday = post anything real-time (stories, live content).",
              "Scheduling in Meta Business Suite: Go to business.facebook.com → Posts → Create Post → write your caption → add media → instead of 'Publish Now', click the dropdown arrow next to it → 'Schedule Post' → choose date and time. This works for Facebook AND Instagram simultaneously.",
              "Events and seasonal content: At the start of every month, note any relevant dates: Algerian national holidays, Ramadan period, Eid, back-to-school, summer, local events. Build content around these. A restaurant posting Ramadan iftar specials 1 week before Ramadan gets massive organic reach because people are searching for it.",
              "Client approval workflow: Never post without client approval. Share the content calendar every 2 weeks with your client via Google Sheets (share link, view only). Create a WhatsApp message: 'Voici le planning du contenu pour les 2 prochaines semaines. Merci de me confirmer avant [date].' If no response in 48 hours, post anyway (state this in your contract)."
            ],
            method: "Steal this workflow: every Sunday evening, spend 30 minutes reviewing the previous week's analytics and 30 minutes planning the next week's content topics. After 4 weeks of this, planning becomes automatic and takes only 15 minutes.",
            exercise: "Build a complete 4-week content calendar in Google Sheets for a fictional Algerian pharmacy page. Include: 16 posts (4 per week), a mix of all 4 content pillars, different formats (photo/carousel/reel), captions drafted for each. Highlight posts tied to any upcoming events or health awareness days.",
            tip: "💡 The biggest difference between amateur and professional SMMs: professionals never scramble for content ideas at posting time. The calendar is done in advance. If you're thinking 'what should I post today?' — you've already failed at content management."
          }
        ]
      },
      {
        name: "Advanced",
        badge: "🔥",
        duration: "Weeks 10–18",
        goal: "Develop full strategies, manage multiple clients, prove ROI with data",
        lessons: [
          {
            title: "How to Write a Professional Social Media Strategy Document",
            steps: [
              "A strategy document is what separates a freelancer who posts photos from a professional strategist who commands 3× higher rates. This document proves you think before you act.",
              "Section 1 — Current Situation Audit (2 pages): Current follower count, average engagement rate (interactions ÷ reach × 100), top 5 best-performing posts (screenshot and analyze), top 5 worst-performing posts, audience demographics currently (age, gender, location from Insights), content types used and their performance, posting frequency, response time to messages.",
              "Section 2 — Competitor Analysis (2 pages): Identify 3–5 direct competitors on social media. For each: their follower count, avg engagement rate, what content types they use, their posting frequency, what performs best for them. Identify GAPS — what topics or formats are they NOT covering that your client could own?",
              "Section 3 — Target Audience Persona (1 page): Full fictional profile of the ideal customer. Name, age, city, job, income level, goals, frustrations, social media habits, favorite content types, what influences their purchase decision.",
              "Section 4 — SMART Goals (1 page): Specific, Measurable, Achievable, Relevant, Time-bound. Example: 'Increase Instagram engagement rate from 1.2% to 4.5% within 90 days.' 'Generate 50 WhatsApp messages per month from Facebook Ads with a budget of 5,000 DZD/month.'",
              "Section 5 — 90-Day Content Strategy (3 pages): Platform selection and rationale, Content pillars (4–5) with descriptions, Content mix by format (% of posts that are Reels vs carousels vs photos), Posting frequency per platform, Hashtag strategy, Paid ads strategy (budget, objectives, audience).",
              "Present this as a designed Canva PDF, not a Word document. A professionally designed strategy document positions you as a premium provider before the client sees your pricing."
            ],
            method: "Write your first strategy document for a real local business even if they haven't hired you. Pick any business with an active Instagram. Do the audit, the competitor analysis, and write the goals and strategy. Send it to them as a free gift with a note: 'J'ai analysé votre présence social media et préparé cette stratégie. Si vous souhaitez que je l'applique, voici mes tarifs.' This cold outreach method has an extremely high response rate because you've already delivered value.",
            exercise: "Write a complete social media strategy document (minimum 8 pages in Canva PDF) for a real or fictional Algerian business. Include all 5 sections above. Present it as if you're presenting to the business owner in a meeting — clear, professional, with data and specific recommendations.",
            tip: "💡 During a strategy presentation, never say 'I think' or 'maybe'. Say 'The data shows' and 'Based on your audience insights'. Confidence backed by data is what clients pay for."
          },
          {
            title: "How to Manage 4+ Clients Simultaneously Without Losing Quality",
            steps: [
              "Client management system: Create a free Notion account (notion.so). Create a page for each client. Inside each client page: profile info, brand guidelines, content calendar, approved post bank, ad campaign tracker, monthly report template, communication log.",
              "The Master Weekly Schedule: Block your time by task type, not by client. Example: Monday 9–12 = all clients' content writing. Monday 13–17 = all clients' graphic design. Tuesday 9–12 = all video editing. Tuesday 13–17 = scheduling all posts. Wednesday = community management for all clients (reply to comments/DMs). Thursday = analytics review + reports. Friday = client calls and planning next week.",
              "Communication rules (set from day 1): With every new client, send this message: 'Pour une meilleure organisation, je réponds aux messages professionnels du lundi au vendredi entre 9h et 18h. Je vous fournis un rapport hebdomadaire chaque lundi.' Clients who text at midnight expecting instant responses will drain your energy and quality.",
              "The Monthly Report template: Section 1 = Summary paragraph (1 paragraph of key wins this month). Section 2 = Metrics table (follower growth, reach, engagement rate, impressions, link clicks, ad results — compare to previous month). Section 3 = Top 3 posts (screenshot + analysis of why they performed). Section 4 = Key learnings. Section 5 = Next month's plan. Send as a PDF every 1st of the month.",
              "Quality control: Before posting ANYTHING for a client, run the 5-second test. Show the post to someone who doesn't know the brand. If they can't tell in 5 seconds what it's promoting, redesign it.",
              "Managing creative approval delays: Clients slow at approving content is the #1 reason SMMs miss posting schedules. Solve this in the contract: 'Le contenu est soumis pour validation 5 jours ouvrables avant publication. Sans retour sous 48h, le contenu sera publié tel quel.'"
            ],
            method: "Before taking on your 4th client, build your entire system FIRST. Spend 1 full day setting up Notion for all existing clients, creating your report template, and writing out your weekly schedule. Trying to build systems while drowning in client work is a recipe for burnout and poor quality.",
            exercise: "Set up a Notion workspace for 3 fictional clients: a restaurant, a clothing boutique, and a fitness coach. Each client gets their own page with: brand info section, this month's content calendar, ad campaign tracker, and a monthly report template. Share the Notion link as if sending to the client.",
            tip: "💡 Fire bad clients. A client who constantly changes direction, doesn't approve content on time, disrespects your schedule, or haggles on every invoice is not worth keeping. One exhausting client takes the energy you could use to find 2 great ones."
          }
        ]
      },
      {
        name: "Master",
        badge: "👑",
        duration: "Month 5+",
        goal: "Build a social media agency with retainer clients and a small team",
        lessons: [
          {
            title: "How to Build an SMM Agency from Scratch",
            steps: [
              "Agency vs freelancer mindset shift: A freelancer sells their time. An agency sells outcomes. Stop saying 'I'll post 3 times per week'. Start saying 'I'll grow your Instagram following by 500+ targeted followers and generate 30+ qualified WhatsApp leads per month within 90 days or I'll work for free until we hit it.'",
              "Build your offer around a guarantee: Most agencies give no guarantees. A results guarantee is your biggest differentiator. Define what metric you can confidently deliver (follower growth rate, engagement rate, number of leads per month). Offer to continue working free if you miss the target. You'll rarely miss it — but the offer alone closes clients.",
              "Hire your first team member: Job description for your first hire: 'Community Manager — will manage daily posting, comments, and messages for 3–4 clients under my supervision. 3–4 hours/day. Pay: 15,000–25,000 DZD/month.' Post this in Facebook groups for digital marketing in Algeria. Interview 5 candidates. Hire based on attitude and communication skills — you can teach the tools.",
              "Pricing for agency packages: Starter (15,000 DZD/month: 12 posts + stories + report), Growth (35,000 DZD/month: 20 posts + reels + ads management + report), Premium (65,000+ DZD/month: full strategy + content + ads + influencer + weekly meeting). A 5-client agency at Growth level = 175,000 DZD/month. This is a real business.",
              "Client acquisition strategy: 1) Referrals from existing clients (offer 10% commission to any client who refers a new client). 2) Cold Instagram DMs to businesses with weak social media. 3) Partnerships with graphic designers, web developers, photographers — refer clients to each other. 4) Speaking at local entrepreneurship events. 5) Publishing free content that demonstrates expertise (post your own tips, case studies, results on LinkedIn and Instagram)."
            ],
            method: "Case study marketing: Document ONE client success story in detail — before (their metrics when you started), what you did (strategy, content types, ads), after (metrics 3 months later). Design it as a 1-page PDF and an Instagram carousel. This single piece of content will get you more clients than any sales pitch ever could.",
            exercise: "Write your agency's full business model on 1 page: your niche (what type of businesses do you serve?), your 3 service packages with prices, your guarantee, your client acquisition strategy (3 channels), and your 6-month revenue goal. This is your agency business plan.",
            tip: "💡 The fastest path to agency: get 1 client → deliver exceptional results → ask them for 1 referral → repeat. You don't need a website, ads, or branding to start. You need 1 successful case study."
          }
        ]
      }
    ]
  },

  // ════════════════════════════════════════════
  // SKILL 3: VIDEO EDITING
  // ════════════════════════════════════════════
  {
    id: "video",
    icon: "🎬",
    color: "#DC2626",
    accent: "#F87171",
    bg: "#1A0303",
    title: "Video Editing",
    subtitle: "Content Creation",
    tagline: "Most in-demand creative skill of the decade",
    earning: "8,000 – 80,000 DZD / project",
    firstClient: "4–6 weeks",
    startTool: "CapCut (free) → DaVinci Resolve (free)",
    levels: [
      {
        name: "Beginner",
        badge: "🌱",
        duration: "Weeks 1–4",
        goal: "Edit your first complete video using CapCut on your phone",
        lessons: [
          {
            title: "How to Install CapCut and Edit Your First Video",
            steps: [
              "Download CapCut from Google Play or App Store — it's completely free with no watermark on exports (as of 2025).",
              "Open CapCut → tap the '+' button → select videos and photos from your gallery → tap 'Add' → your timeline opens.",
              "The timeline at the bottom: your clips appear as blocks. Tap any clip to select it (it gets a white border). When selected, the bottom panel shows tools: Split, Delete, Speed, etc.",
              "How to Split (cut) a clip: Drag the white vertical line (playhead) to the exact moment you want to cut → tap 'Split'. The clip is now 2 separate pieces. Delete the part you don't want by selecting it and tapping 'Delete'.",
              "How to add music: Tap 'Audio' in the bottom bar → 'Sounds' → search for a song or browse by mood → tap the '+' to add it to your timeline. Adjust the volume by selecting the audio track → 'Volume'. Lower it to about 30% if you have voice/dialogue in the video.",
              "How to add text: Tap 'Text' → 'Add Text' → type → choose font and color from the bottom → drag the text box to position on screen. Tap the text clip on the timeline to change when it appears and for how long.",
              "How to export: Tap the arrow icon top right → select resolution (1080p) and frame rate (30fps) → tap the export button → it saves to your gallery. For Instagram Reels: vertical 9:16. For YouTube: horizontal 16:9."
            ],
            method: "Film exactly 10 short clips of anything (your hand, the street outside, your cup of coffee, a wall, a plant — it doesn't matter). Import all 10 into CapCut. Cut them to keep only the best 3 seconds of each. Add background music. Export. You've just made your first edit. Now watch it back and notice what looks good and what looks awkward. That self-critique IS the learning.",
            exercise: "Create a 60-second video about your day using only clips filmed today on your phone. Must include: minimum 8 different clips, background music, your name as text at the beginning, and a simple title at the end. Export and watch it. Notice every moment that feels 'off' — these are your lessons.",
            tip: "💡 The most common beginner mistake: clips that are too long. Every clip in a social media video should be 1.5–4 seconds maximum. When in doubt, cut earlier. Fast-paced editing always feels more professional than slow dragging shots."
          },
          {
            title: "How to Cut on the Beat — Music-Driven Editing",
            steps: [
              "Beat-synced editing means: every time you cut from one clip to the next, it happens EXACTLY when the music has a drum hit, bass drop, or significant sound. This creates a hypnotic 'feel' that makes videos addictive to watch.",
              "Step 1 — Choose your music first: Before adding any clips, add your music track to the timeline. Listen through the whole song once.",
              "Step 2 — Mark the beats: In CapCut, play your audio track and tap 'Beats' (in newer versions) to auto-detect beats, which adds markers. If your version doesn't have this: play the audio and tap the screen on each beat — CapCut adds a marker each time you tap.",
              "Step 3 — Trim your clips to match: Now place your clips in the timeline and TRIM each clip to end exactly where a beat marker falls. The transition from clip to clip happens on the beat.",
              "Step 4 — Verify: Play the whole video through while CLOSING YOUR EYES and just listening. Every time you feel a beat, open your eyes for a split second. If there's a cut at that moment — good. If not — you need to adjust.",
              "For very fast songs: cut every 1–2 beats. For slow emotional songs: cut every 4–8 beats. For dramatic build-ups in music: hold on one clip through the build, then cut at the peak/drop."
            ],
            method: "Take any music track you like and film 30 random clips (2–3 seconds each) of anything. Then do ONLY beat-synced editing — don't try to make the clips 'make sense' as a story. Just focus on making every single cut land on a beat. Watch the result. Even random footage looks impressive with perfect beat-sync.",
            exercise: "Create a 45-second beat-synced montage using footage of your city or neighborhood (film outside for 30 minutes — get minimum 20 clips). Use a trending song. Every single cut must land on a beat. Export and share to your practice account. This is a real piece for your portfolio.",
            tip: "💡 CapCut's 'Auto Beat Sync' feature (under Audio → Beats) automatically places cuts on the beats of any song. Use this as training wheels to see where the beats fall, then learn to feel it yourself."
          },
          {
            title: "How to Color Grade a Video (Make it Look Cinematic)",
            steps: [
              "Color grading happens in 2 stages: Correction (fix technical problems) → then Creative Grade (add mood/style).",
              "In CapCut, select a clip → tap 'Adjust': Brightness (negative = darker, positive = brighter), Contrast (increases the difference between darks and lights), Saturation (negative = less color = more grey, positive = more vivid), Sharpness (increase slightly, max 30), Highlight (reduce to recover blown-out white areas), Shadow (increase to reveal dark areas).",
              "Basic color correction order: 1. Set Exposure/Brightness so the video looks naturally lit. 2. Adjust Contrast until blacks look black and whites look white. 3. Set Saturation to natural level. 4. Adjust White Balance (Warmth) — warmer = more yellow/orange, cooler = more blue.",
              "The cinematic teal-orange grade (most popular film look): In CapCut Filters → look for 'Cinematic' category. Alternatively manually: increase Warmth slightly (+15), reduce Saturation (-10), increase Contrast (+20), add a subtle vignette (darker edges). This pushes skin tones toward orange and shadows toward teal.",
              "Applying the same grade to multiple clips: In CapCut, adjust one clip → tap the 3 dots → 'Copy Style' → select all other clips → 'Paste Style'. This is how you create visual consistency across a multi-clip video.",
              "LUTs (Look-Up Tables) are one-click color grades used by professionals. CapCut supports LUTs: Adjust → Filter → Import LUT → choose a downloaded .CUBE file. Search YouTube for 'free cinematic LUTs download' — download 10, try them all, keep your favorites."
            ],
            method: "Film the same scene 3 times in different lighting conditions: direct sunlight, shade, and indoor artificial light. Import all 3 into CapCut. Color correct them until they all look like they were filmed in the same lighting. This is the most practical color correction exercise — because clients will always give you footage from inconsistent conditions.",
            exercise: "Take any raw video you've filmed (doesn't matter what it is). Apply 3 different color grades to the same clip: 1) Warm golden hour look, 2) Cold blue dramatic look, 3) Desaturated film look. Export all 3 as separate clips and write which mood each one creates and which type of content each would suit.",
            tip: "💡 The most important rule in color grading: less is more. A 10% adjustment looks professional. A 50% adjustment looks like a beginner who discovered sliders for the first time. Subtle changes that you barely notice individually add up to a refined look."
          },
          {
            title: "How to Fix Bad Audio and Add Professional Sound Design",
            steps: [
              "The fastest free audio fix: Go to podcast.adobe.com/enhance — completely free. Upload any audio file (up to 1 hour). It uses AI to remove background noise and enhance voice clarity in 30 seconds. This single tool transforms phone recordings into studio-quality audio.",
              "Audio levels in video (the rules): Background music = -20 to -25 dB (barely audible under speech). Narration/dialogue = -12 to -6 dB (clearly heard). Sound effects = -15 to -18 dB. In CapCut: select audio track → 'Volume' → adjust slider (100% ≈ original level, reduce music to 20–30%).",
              "How to add sound effects: Go to freesound.org — free account, thousands of effects. Search for: 'whoosh' (for text flying in), 'click' (for UI elements), 'crowd' (for energy), 'notification' (for tips). Download as MP3. Import to CapCut via Audio → Import.",
              "The J-Cut technique: Start the audio from the next scene 0.5–1 second BEFORE the visual cuts to it. This creates a seamless, natural-feeling transition. In CapCut: split your audio at the cut point, slide the next scene's audio slightly left so it starts before the visual cut.",
              "Music selection resources (royalty-free = safe to use): YouTube Audio Library (free, search by mood/genre), Pixabay Music (free), Mixkit (free). NEVER use a copyrighted song on client work — their content could get taken down or claimed.",
              "Sync audio to action: If someone claps in the video, the 'clap' sound effect must land on the exact frame of the hands touching. If there's a text animation flying in, the 'whoosh' sound must start 2 frames before the text appears. This sync is what makes professional edits feel polished."
            ],
            method: "Silent video exercise: Find any video with no audio (or mute a video you have). Add complete sound design from scratch: background ambience, sound effects for every action, background music. Use only free resources. The goal is to make the video feel REAL and immersive through audio alone. This is how film audio editors think.",
            exercise: "Record 3 minutes of yourself giving a tip or tutorial about anything you know (cooking, fitness, any topic). The audio will be imperfect. Run it through Adobe Podcast Enhance. Import the enhanced audio back into CapCut. Add background music at -22dB. Add a sound effect at the beginning and end. Compare the before and after — this will permanently change how you think about audio.",
            tip: "💡 A video with perfect color grading but bad audio feels amateurish. A video with mediocre color but crystal-clear audio feels professional. When you have limited time, fix audio first."
          }
        ]
      },
      {
        name: "Intermediate",
        badge: "⚡",
        duration: "Weeks 5–11",
        goal: "Learn DaVinci Resolve, specialize in a video type, build your portfolio",
        lessons: [
          {
            title: "How to Set Up and Use DaVinci Resolve (Professional Free Tool)",
            steps: [
              "Download DaVinci Resolve from blackmagicdesign.com/products/davinciresolve — select 'DaVinci Resolve' (free), not 'DaVinci Resolve Studio' (paid). Install normally.",
              "First time setup: Open DaVinci Resolve → New Project → name it → OK. Go to File → Project Settings → set Timeline Frame Rate to 25fps (standard for Algeria/Europe) and Timeline Resolution to 1920×1080 (Full HD).",
              "The 5 pages (tabs at the bottom): Cut (fast rough editing), Edit (full professional timeline — use this), Fusion (motion graphics — advanced), Color (best color grading tool in the world), Fairlight (professional audio). Start only with Edit and Color.",
              "Importing footage: File → Import → Import Media → select your video files → they appear in the 'Media Pool' top left. Drag clips from Media Pool to the Timeline at the bottom.",
              "Basic editing in Edit page: Blade tool (B on keyboard) = cuts clips. Selection tool (A) = move/select. Delete a selected clip = Backspace. Close the gap left by deleted clip: right-click → 'Delete Gap'. Trim the start of a clip: hover your cursor at the very edge of the clip until the cursor changes to a trim icon, then drag.",
              "Exporting: Go to 'Deliver' page (bottom right icon). Select a preset: YouTube (for social media), or Custom (set your own: H.264 format, 1080p, 10 Mbps bitrate). Click 'Add to Render Queue' → 'Render All'. File saves to your chosen location."
            ],
            method: "Import any 5-minute video footage into DaVinci Resolve. Your only task: cut out every moment where nothing interesting is happening. If someone is walking to their car, cut to when they arrive. If someone is talking and pauses for 3 seconds, cut the pause. At the end, the video should only contain its best moments. This exercise teaches the core principle of editing: removing everything that doesn't need to be there.",
            exercise: "Edit a 3-minute travel or event video in DaVinci Resolve from raw footage (find free footage on pexels.com/videos if you don't have your own). Must include: proper cuts, background music (royalty-free), at least 2 different text styles (title + lower third), and basic color correction using the Color page. Export at 1080p.",
            tip: "💡 The keyboard shortcut that will save you hours: press 'I' to mark the IN point of a clip (where you want it to start) and 'O' to mark the OUT point (where you want it to end) in the viewer — then press 'F9' to automatically add it to your timeline. This is the professional editing workflow."
          },
          {
            title: "How to Edit a Wedding Highlight Film",
            steps: [
              "Wedding editing is the most lucrative local video niche in Algeria (10,000–50,000 DZD per project). Structure of a 4-minute wedding highlight film: Opening (0–30s): best moment from later in the day, sets the mood. Getting Ready (30–60s): bride/groom preparation, emotional details. Ceremony (1:00–2:00): key vows moments, first kiss, audience reactions. Celebration (2:00–3:30): first dance, family moments, joy and fun. Closing (3:30–4:00): a quiet, emotional final shot — couple walking away, sunset, a detail shot.",
              "Music selection for wedding films: Choose 1 song for the whole film or 2 songs (1 slower for ceremony, 1 upbeat for celebration). The music MUST fit the couple's personality. Sources: Artlist.io (paid subscription, professional), Musicbed.com (paid), or search 'royalty free wedding music' on YouTube for free options.",
              "Color grading for weddings: The standard wedding look is warm, soft, and romantic. In DaVinci Resolve Color page: add a node → reduce Highlights slightly → add warmth (shift color balance toward orange in midtones) → reduce Saturation to -15 to -25 (desaturated looks more film-like) → add slight vignette. Skin tones must always look healthy and natural — never orange or green.",
              "Slow motion: Film important moments at 60fps (phone slow motion setting). In editing, set these clips to 50% speed. Key moments for slow motion: the first look, the ring exchange, the first dance spin, bouquet toss, happy tears.",
              "The emotional edit: Great wedding films make people cry. This comes from: choosing shots that capture genuine emotion (not posed ones), letting moments breathe (don't cut too fast during emotional peaks), matching the music's emotional arc to the visual story.",
              "Delivery: Export at 4K if possible, 1080p minimum. Deliver via: a high-quality link (WeTransfer.com for large files — free) + a USB drive in a nice case. Also export a 90-second 'Teaser' version for Instagram Reels — this is free marketing for you."
            ],
            method: "Find any free wedding footage online (search 'free wedding stock footage' on Pexels or Pixabay). Edit a full 4-minute highlight film following the structure above. This is your wedding editing portfolio piece. It demonstrates the skill even without real client footage.",
            exercise: "Edit a complete 4-minute wedding highlight film from free stock footage. Grade it with a warm romantic look. Create a 60-second Reel teaser version. Write a price list for your wedding video editing service (3 packages: Teaser only, Highlight film, Full day edit). This becomes your first offering.",
            tip: "💡 Approach wedding photographers, not brides directly. Photographers shoot every wedding and need a trusted video editor. One good relationship with a photographer gives you 10–20 weddings per year. Offer them a referral fee (1,000–2,000 DZD per client they send)."
          },
          {
            title: "How to Edit YouTube Videos That Hold Attention",
            steps: [
              "YouTube retention rule: If 30% of your audience drops off in the first 30 seconds — the video will fail. Your ONLY goal in the first 30 seconds is to make the viewer believe this video is worth watching until the end.",
              "The pattern interrupt technique: Every 60–90 seconds, add a visual change that prevents the brain from losing interest. Options: zoom in on the speaker's face, cut to B-roll footage, add text animation on screen, change the music underneath, add a sound effect, cut to a diagram or image. Never hold on the same shot for more than 90 seconds without a visual change.",
              "Jump cuts: In talking head YouTube videos, cut out every pause, filler word ('um', 'euh', 'donc'), and dead silence longer than 0.3 seconds. In DaVinci Resolve: use the Blade tool to cut out each pause. This seems extreme but is how every major YouTuber's content is edited. The result feels energetic and respects the viewer's time.",
              "B-roll over voice: When the speaker says 'and then I went to the market', cut AWAY from their face to footage of a market (B-roll). Rule: face-to-camera talking head should never go more than 20–30 seconds without cutting to B-roll. Sources for B-roll if you don't have it: Pexels.com/videos (free), Pixabay.com/videos (free).",
              "End screen setup: In the last 20 seconds of every YouTube video, add end screen elements: subscribe button, 'next video' card, a 'recommended video' card. In YouTube Studio (not the editor), you add these AFTER uploading. In the video editor, leave the last 20 seconds relatively simple (just the person speaking or a static graphic) so the YouTube overlays are visible.",
              "Chapters (timestamps): In the YouTube description, add timestamps: '0:00 Introduction, 1:30 Step 1, 3:45 Step 2, 6:20 Final result'. YouTube shows these as chapters on the progress bar. Videos with chapters get more views because viewers can skip to the part they want — this increases completion rate."
            ],
            method: "Watch your own content with a critical eye: Load any video on YouTube. Open the Analytics for that video. Click 'Audience Retention'. You'll see a graph showing at what second viewers drop off. Every drop = something went wrong at that point. Go to that exact second in the video and identify why people left. Fix it in future videos. This data-driven approach is what separates growing channels from stagnant ones.",
            exercise: "Find any 10-minute educational video on YouTube (any topic). Download it (use y2mate.com or similar). Edit it DOWN to 6 minutes: remove all filler words, unnecessary pauses, and repetitive sections using DaVinci Resolve. Then add: 3 text animations, 2 pieces of B-roll, 1 chapter title card. Export and compare your version to the original.",
            tip: "💡 The highest-paid YouTube editors are not the ones who add the most effects — they're the ones who make the content feel effortless and keep viewers watching. Invisible editing is the hardest and most valuable skill."
          }
        ]
      },
      {
        name: "Advanced",
        badge: "🔥",
        duration: "Weeks 12–20",
        goal: "Master DaVinci Resolve Color page, VFX basics, command premium rates",
        lessons: [
          {
            title: "How to Master Color Grading in DaVinci Resolve",
            steps: [
              "Go to the Color page in DaVinci Resolve. You'll see the node graph on the right — think of each node as a separate, stackable color adjustment. Node 1 = Color Correction (fixing technical issues). Node 2 = Creative Grade (adding mood). Node 3 = Specific adjustments if needed.",
              "The 3 scopes (Workspace → Scopes): Waveform (left-right = left-right of screen, up-down = brightness — bottom of waveform should touch 0, top should reach 100 for a well-exposed image). Parade (same as waveform but splits into R, G, B channels — all 3 should be balanced for neutral white balance). Vectorscope (shows saturation and hue — the skin tone indicator line should pass through your subject's skin tone).",
              "Primary Wheels: Lift (shadows — bottom of image), Gamma (midtones — middle tones), Gain (highlights — bright areas). Drag these wheels toward a color to tint that range. For cinematic teal-orange: drag Lift slightly toward teal/cyan, drag Gain slightly toward warm orange.",
              "Qualifier tool: Click the eyedropper in the Color page. Click on any color in your image (e.g., the sky, or someone's skin). DaVinci isolates ONLY that color for adjustment. Now you can change the sky's color without affecting anything else. This is how professionals do secondary color correction.",
              "Matching shots: When you have footage from 2 different cameras or lighting conditions, right-click on your well-graded clip in the Color page → 'Grab Still' (saves a reference frame). Then go to a poorly matched clip → right-click in the Stills panel → 'Apply Grade'. DaVinci attempts to match the color automatically. Then fine-tune manually.",
              "The LUT workflow: File → Project Settings → Color Management → add a LUT folder. Or in Color page, right-click a node → 'LUTs' → browse and apply. Always apply a LUT on its own node, then reduce the node opacity to 30–70% — full LUTs at 100% almost always look overdone."
            ],
            method: "Grade the same 2-minute clip 5 different ways to create 5 completely different moods: 1) Warm golden afternoon, 2) Cold clinical/thriller, 3) Faded vintage film, 4) High contrast action, 5) Soft romantic. Export all 5. This single exercise teaches you more about color than any amount of theory. Save these grades as 'Power Grades' in DaVinci to reuse on future projects.",
            exercise: "Download 3 different clips from Pexels (an outdoor scene, an indoor portrait, a night scene). Grade all 3 so they look like they belong to the same film — consistent color temperature, consistent contrast, consistent mood. Show the before and after for each clip. This is the core skill clients pay premium for.",
            tip: "💡 Colorists do not guess — they use scopes. Before touching ANY grade, look at the waveform and fix the technical exposure first. A creative grade on a technically wrong exposure always looks bad."
          },
          {
            title: "How to Set Your Rates and Get High-Paying Video Clients",
            steps: [
              "Video editing pricing for Algeria (intermediate-advanced): 30-second Reel edit = 3,000–8,000 DZD. 3–5 minute YouTube video = 8,000–20,000 DZD. 4-minute wedding highlight = 15,000–40,000 DZD. Full wedding day edit (30–90 min) = 30,000–80,000 DZD. Commercial ad (30 sec, full production) = 30,000–120,000 DZD. Monthly Reels package (8 Reels/month) = 20,000–50,000 DZD.",
              "Building a showreel: A showreel is a 60–90 second video of your BEST work, edited together. Structure: start with your most impressive shot (first 3 seconds must be stunning), include variety (wedding, commercial, educational, social media), show range of color grades and styles, end on a strong brand moment with your name/contact. This is sent to every potential client.",
              "Where to find video editing clients in Algeria: 1. Wedding photographers (find them on Instagram — all of them need editors). 2. YouTubers in Algeria with 5,000–50,000 subscribers who can't edit themselves. 3. Brands running social media ads. 4. Event companies (conferences, corporate events, launches). 5. International clients via Fiverr (paid in USD/EUR — multiply your rate by the exchange rate).",
              "Cold outreach formula for video editors: 'Bonjour [Name], je suis éditeur vidéo spécialisé dans [wedding films / content creation / ads]. J'ai regardé votre page et j'ai quelques idées pour améliorer vos vidéos. Voici un exemple de mon travail: [link to showreel]. Je serais ravi de vous offrir un premier montage test gratuitement pour vous montrer ce que je peux faire. Intéressé(e)?'",
              "The free test edit offer: Offer to edit 1 short video for free for any serious prospect. If they're a wedding photographer: offer to edit a 60-second teaser from footage they already have. Cost to you: 3–4 hours. Potential return: a client who sends you 15 weddings per year.",
              "Upselling: Every editing project is an opportunity to sell adjacent services. Wedding edit → also offer a Reel teaser. YouTube edit → offer a thumbnail design (3,000–5,000 DZD extra). Commercial edit → offer a 15-second cut-down for stories (2,000 DZD extra)."
            ],
            method: "Today, find 10 wedding photographers on Instagram in your city. Go to their profiles. Look for whether they offer video. Most won't — that's your opening. Send a simple DM to 5 of them right now. Not a pitch — just start a conversation: 'Salam, votre travail est vraiment beau. Vous collaborez avec des vidéastes/éditeurs?'. When they respond, THEN present what you offer.",
            exercise: "Create your video editing showreel (60–90 seconds): compile your best clips from all exercises in this course. Add text overlays showing the project type and your name. Add an energetic music track. Export at 1080p. This is the first link you'll share with every potential client.",
            tip: "💡 Price per project, not per hour — for video editing. Clients don't need to know it took you 6 hours. They pay for the result. As you get faster, your effective hourly rate increases without changing your project price."
          }
        ]
      },
      {
        name: "Master",
        badge: "👑",
        duration: "Month 6+",
        goal: "Produce commercial videos, build a production company",
        lessons: [
          {
            title: "How to Produce and Edit a Commercial Advertisement",
            steps: [
              "A commercial ad (publicité) follows a specific narrative structure in 30–60 seconds: 0–5s: Problem or tension (show the pain, the struggle, the need). 5–20s: Introduction of the solution (show the product arriving or being used). 20–28s: Transformation and benefit (show the person after using the product — better, happier, more successful). 28–30s: Call to action (logo + tagline + where to buy).",
              "Pre-production for a commercial: Client brief → script → storyboard (draw every single shot on paper before filming) → shot list (list every clip you need: wide shot of person, close-up of product, hands using the product, face reaction) → location scouting → talent (actors/models) → props list → filming day schedule.",
              "On-set coordination: Even for small productions, you're the director. Direct the talent (tell them exactly what to do, how to feel, what to look at). Get minimum 3 takes of every shot. Vary the angles: wide establishing shot, medium shot, close-up detail. Never leave the location without all the shots on your list.",
              "Post-production for commercials: Picture edit first (rough cut, structure, timing). Then sound design (voiceover recording if needed, music, sound effects). Then color grade (match brand colors in the grade). Then graphics (logo reveals, lower thirds, end card). Then final review with client. Then export in multiple formats: 16:9 for YouTube/TV, 9:16 for Stories, 1:1 for Instagram feed.",
              "Voiceover recording: For most Algerian brand commercials, a professional voiceover in Algerian Darija or French dramatically increases conversion. Find voiceover artists on Facebook groups (search 'voix off algérie') or record it yourself in a quiet room using your phone close to your mouth, then enhance with Adobe Podcast.",
              "Commercial pricing: A 30-second social media commercial (filming + editing) = 40,000–120,000 DZD. A TV commercial (much higher quality requirements) = 150,000–500,000 DZD. These prices are for the full production. If you're only editing footage someone else filmed, divide these by 3."
            ],
            method: "Create your first spec commercial: Pick any real local product you use (a phone, a drink, a food product). Write a 30-second script. Storyboard it. Film it yourself (you're the actor too if needed). Edit it professionally. Post it on Instagram tagging the brand. This spec work has literally gotten video editors hired by the brands they tagged — it's a real strategy.",
            exercise: "Script, storyboard, film, and edit a complete 30-second commercial for a fictional Algerian organic juice brand called 'Sahara Fresh'. Film in a clean location. Edit with the full commercial structure. Grade it with vibrant, healthy-looking colors. Add background music and a voiceover. Export 2 versions: horizontal (YouTube) and vertical (Reels). This is your flagship portfolio piece.",
            tip: "💡 The commercial editor who also understands strategy (why certain shots work, what emotions drive purchase decisions) earns 3× more than one who just knows the software. Study advertising psychology alongside your technical skills."
          }
        ]
      }
    ]
  }
];

const LEVEL_STYLES = {
  "Beginner":     { bg: "#052E16", border: "#16A34A", text: "#4ADE80", badge: "🌱" },
  "Intermediate": { bg: "#1E3A5F", border: "#2563EB", text: "#60A5FA", badge: "⚡" },
  "Advanced":     { bg: "#450A0A", border: "#DC2626", text: "#F87171", badge: "🔥" },
  "Master":       { bg: "#431407", border: "#EA580C", text: "#FB923C", badge: "👑" }
};

// ─────────────────────────────────────────────
// COMPONENT
// ─────────────────────────────────────────────
export default function Academy() {
  const [view, setView] = useState("home"); // home | skill | lesson
  const [skillId, setSkillId] = useState(null);
  const [levelIdx, setLevelIdx] = useState(0);
  const [lessonIdx, setLessonIdx] = useState(null);
  const [openStep, setOpenStep] = useState(null);

  const skill = skills.find(s => s.id === skillId);

  // ── HOME ──────────────────────────────────
  if (view === "home") return (
    <div style={{ minHeight: "100vh", background: "#060608", color: "#E5E7EB", fontFamily: "system-ui, -apple-system, sans-serif" }}>
      <div style={{ background: "linear-gradient(180deg, #0D0818 0%, #060608 100%)", padding: "52px 20px 44px", textAlign: "center", borderBottom: "1px solid #1C1C28" }}>
        <div style={{ display: "inline-block", background: "#0D0818", border: "1px solid #7C3AED55", borderRadius: 6, padding: "5px 14px", marginBottom: 18, fontSize: 11, color: "#A78BFA", letterSpacing: 3, textTransform: "uppercase" }}>
          🇩🇿 Digital Skills Academy — Algeria
        </div>
        <h1 style={{ fontSize: "clamp(26px, 6vw, 52px)", fontWeight: 900, margin: "0 0 14px", background: "linear-gradient(135deg, #fff 30%, #A78BFA)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
          Learn It. Practice It.<br />Get Paid.
        </h1>
        <p style={{ color: "#6B7280", fontSize: 16, maxWidth: 520, margin: "0 auto 32px", lineHeight: 1.65 }}>
          3 skills, beginner to master. Every lesson tells you <strong style={{ color: "#9CA3AF" }}>exactly how</strong> to do it — not just what.
        </p>
        <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 16, fontSize: 13, color: "#4B5563" }}>
          {["Step-by-step methods", "Real exercises", "Free tools only", "Algerian market rates"].map(t => (
            <span key={t} style={{ background: "#0F0F18", border: "1px solid #1C1C28", borderRadius: 20, padding: "6px 14px" }}>✓ {t}</span>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 860, margin: "44px auto", padding: "0 20px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 20 }}>
        {skills.map(s => (
          <div key={s.id}
            onClick={() => { setSkillId(s.id); setLevelIdx(0); setLessonIdx(null); setView("skill"); }}
            style={{ background: s.bg, border: `2px solid ${s.color}30`, borderRadius: 16, padding: 26, cursor: "pointer", transition: "all 0.2s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = s.color; e.currentTarget.style.transform = "translateY(-3px)"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = s.color + "30"; e.currentTarget.style.transform = "none"; }}
          >
            <div style={{ fontSize: 44, marginBottom: 14 }}>{s.icon}</div>
            <div style={{ fontSize: 10, color: s.accent, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{s.subtitle}</div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: "#fff", margin: "0 0 8px" }}>{s.title}</h2>
            <p style={{ color: "#6B7280", fontSize: 13, lineHeight: 1.5, margin: "0 0 18px" }}>{s.tagline}</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 18, borderTop: "1px solid #ffffff10", paddingTop: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ color: "#4B5563" }}>First client</span>
                <span style={{ color: s.accent, fontWeight: 600 }}>{s.firstClient}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ color: "#4B5563" }}>Earning range</span>
                <span style={{ color: s.accent, fontWeight: 600, fontSize: 11 }}>{s.earning}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ color: "#4B5563" }}>Start with</span>
                <span style={{ color: "#9CA3AF", fontSize: 11 }}>{s.startTool}</span>
              </div>
            </div>
            <div style={{ background: s.color, borderRadius: 8, padding: "10px", textAlign: "center", fontWeight: 700, fontSize: 14, color: "#fff" }}>
              Start Learning →
            </div>
          </div>
        ))}
      </div>

      <div style={{ maxWidth: 860, margin: "0 auto 48px", padding: "0 20px" }}>
        <div style={{ background: "#0D0818", border: "1px solid #1C1C28", borderRadius: 12, padding: 20, textAlign: "center" }}>
          <p style={{ color: "#4B5563", fontSize: 13, margin: 0 }}>
            💡 <strong style={{ color: "#6B7280" }}>Recommended order:</strong> Start with <strong style={{ color: "#34D399" }}>Social Media Management</strong> (fastest first client) → add <strong style={{ color: "#A78BFA" }}>Graphic Design</strong> → add <strong style={{ color: "#F87171" }}>Video Editing</strong>
          </p>
        </div>
      </div>
    </div>
  );

  // ── SKILL / LEVEL VIEW ─────────────────────
  if (view === "skill" && skill && lessonIdx === null) {
    const level = skill.levels[levelIdx];
    const ls = LEVEL_STYLES[level.name];
    return (
      <div style={{ minHeight: "100vh", background: "#060608", color: "#E5E7EB", fontFamily: "system-ui, sans-serif" }}>
        {/* Header */}
        <div style={{ background: skill.bg, borderBottom: `1px solid ${skill.color}25`, padding: "16px 20px" }}>
          <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <button onClick={() => setView("home")} style={{ background: "transparent", border: "1px solid #1C1C28", color: "#6B7280", borderRadius: 8, padding: "7px 12px", cursor: "pointer", fontSize: 13 }}>← Skills</button>
            <span style={{ fontSize: 26 }}>{skill.icon}</span>
            <div>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#fff" }}>{skill.title}</div>
              <div style={{ fontSize: 11, color: skill.accent }}>{skill.earning}</div>
            </div>
          </div>
        </div>

        <div style={{ maxWidth: 860, margin: "0 auto", padding: "28px 20px" }}>
          {/* Level tabs */}
          <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
            {skill.levels.map((l, i) => {
              const lsTab = LEVEL_STYLES[l.name];
              const active = levelIdx === i;
              return (
                <button key={i}
                  onClick={() => { setLevelIdx(i); setLessonIdx(null); }}
                  style={{ background: active ? lsTab.bg : "transparent", border: `2px solid ${active ? lsTab.border : "#1C1C28"}`, borderRadius: 10, padding: "9px 16px", cursor: "pointer", color: active ? lsTab.text : "#4B5563", fontWeight: active ? 700 : 400, fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}
                >
                  {lsTab.badge} {l.name}
                </button>
              );
            })}
          </div>

          {/* Level header */}
          <div style={{ background: ls.bg, border: `1px solid ${ls.border}40`, borderRadius: 12, padding: 20, marginBottom: 24 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 10 }}>
              <span style={{ fontSize: 30 }}>{ls.badge}</span>
              <div>
                <div style={{ fontSize: 20, fontWeight: 800, color: "#fff" }}>{level.name} Level</div>
                <div style={{ fontSize: 12, color: "#4B5563" }}>{level.duration}</div>
              </div>
              <div style={{ marginLeft: "auto", background: "#00000030", borderRadius: 8, padding: "8px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: ls.text }}>{level.lessons.length}</div>
                <div style={{ fontSize: 10, color: "#4B5563" }}>lessons</div>
              </div>
            </div>
            <p style={{ color: "#6B7280", fontSize: 13, margin: 0 }}><strong style={{ color: "#9CA3AF" }}>Goal:</strong> {level.goal}</p>
          </div>

          {/* Lesson cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {level.lessons.map((lesson, i) => (
              <div key={i}
                onClick={() => { setLessonIdx(i); setOpenStep(null); setView("lesson"); window.scrollTo(0,0); }}
                style={{ background: "#0D0D14", border: `1px solid #1C1C28`, borderRadius: 12, padding: "18px 20px", cursor: "pointer", display: "flex", alignItems: "center", gap: 14, transition: "all 0.15s" }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = skill.color + "66"; e.currentTarget.style.background = "#111118"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#1C1C28"; e.currentTarget.style.background = "#0D0D14"; }}
              >
                <span style={{ width: 32, height: 32, background: skill.color + "22", border: `1px solid ${skill.color}44`, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: skill.accent, fontWeight: 700, flexShrink: 0 }}>{i + 1}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 15, color: "#E5E7EB", marginBottom: 3 }}>{lesson.title}</div>
                  <div style={{ fontSize: 12, color: "#4B5563" }}>{lesson.steps.length} steps · includes exercise</div>
                </div>
                <span style={{ color: "#374151", fontSize: 20 }}>→</span>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 28, gap: 10 }}>
            {levelIdx > 0
              ? <button onClick={() => { setLevelIdx(levelIdx - 1); setLessonIdx(null); }} style={{ background: "#0D0D14", border: "1px solid #1C1C28", borderRadius: 10, padding: "11px 18px", cursor: "pointer", color: "#6B7280", fontSize: 13 }}>← {skill.levels[levelIdx - 1].name}</button>
              : <div />
            }
            {levelIdx < skill.levels.length - 1 &&
              <button onClick={() => { setLevelIdx(levelIdx + 1); setLessonIdx(null); window.scrollTo(0,0); }} style={{ background: skill.color, border: "none", borderRadius: 10, padding: "11px 20px", cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 700 }}>Next: {skill.levels[levelIdx + 1].name} →</button>
            }
          </div>
        </div>
      </div>
    );
  }

  // ── LESSON VIEW ───────────────────────────
  if (view === "lesson" && skill && lessonIdx !== null) {
    const level = skill.levels[levelIdx];
    const lesson = level.lessons[lessonIdx];
    const ls = LEVEL_STYLES[level.name];

    return (
      <div style={{ minHeight: "100vh", background: "#060608", color: "#E5E7EB", fontFamily: "system-ui, sans-serif" }}>
        {/* Header */}
        <div style={{ background: "#0A0A12", borderBottom: "1px solid #1C1C28", padding: "14px 20px", position: "sticky", top: 0, zIndex: 10 }}>
          <div style={{ maxWidth: 780, margin: "0 auto", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <button onClick={() => setView("skill")} style={{ background: "transparent", border: "1px solid #1C1C28", color: "#6B7280", borderRadius: 8, padding: "6px 11px", cursor: "pointer", fontSize: 12 }}>← Back</button>
            <span style={{ fontSize: 16 }}>{skill.icon}</span>
            <span style={{ fontSize: 12, color: "#4B5563" }}>{skill.title} /</span>
            <span style={{ fontSize: 12, color: ls.text }}>{level.name}</span>
            <span style={{ marginLeft: "auto", fontSize: 12, color: "#374151" }}>Lesson {lessonIdx + 1} of {level.lessons.length}</span>
          </div>
        </div>

        <div style={{ maxWidth: 780, margin: "0 auto", padding: "32px 20px 60px" }}>
          {/* Title */}
          <div style={{ marginBottom: 28 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <span style={{ background: ls.bg, border: `1px solid ${ls.border}`, borderRadius: 8, padding: "4px 12px", fontSize: 12, color: ls.text, fontWeight: 600 }}>{ls.badge} {level.name}</span>
              <span style={{ color: "#374151", fontSize: 12 }}>Lesson {lessonIdx + 1}</span>
            </div>
            <h1 style={{ fontSize: "clamp(20px, 4vw, 28px)", fontWeight: 800, color: "#fff", margin: "0 0 10px", lineHeight: 1.25 }}>{lesson.title}</h1>
          </div>

          {/* HOW TO STEPS */}
          <div style={{ marginBottom: 28 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <div style={{ width: 4, height: 20, background: skill.color, borderRadius: 2 }} />
              <span style={{ fontSize: 14, fontWeight: 700, color: "#fff", textTransform: "uppercase", letterSpacing: 1 }}>How To Do It — Step by Step</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {lesson.steps.map((step, i) => {
                const isOpen = openStep === i;
                return (
                  <div key={i} style={{ background: "#0D0D14", border: `1px solid ${isOpen ? skill.color + "60" : "#1C1C28"}`, borderRadius: 10, overflow: "hidden", transition: "border-color 0.15s" }}>
                    <button
                      onClick={() => setOpenStep(isOpen ? null : i)}
                      style={{ width: "100%", background: "transparent", border: "none", padding: "14px 16px", display: "flex", alignItems: "flex-start", gap: 12, cursor: "pointer", textAlign: "left" }}
                    >
                      <span style={{ width: 24, height: 24, background: isOpen ? skill.color : "#1C1C28", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: isOpen ? "#fff" : "#4B5563", fontWeight: 700, flexShrink: 0, marginTop: 1 }}>{i + 1}</span>
                      <span style={{ fontSize: 14, color: isOpen ? "#fff" : "#9CA3AF", flex: 1, lineHeight: 1.5, fontWeight: isOpen ? 600 : 400 }}>
                        {step.length > 80 && !isOpen ? step.substring(0, 80) + "…" : step}
                      </span>
                      <span style={{ color: "#374151", fontSize: 16, flexShrink: 0, marginTop: 2 }}>{isOpen ? "▲" : "▼"}</span>
                    </button>
                    {isOpen && (
                      <div style={{ padding: "0 16px 16px 52px" }}>
                        <p style={{ color: "#9CA3AF", fontSize: 14, lineHeight: 1.75, margin: 0 }}>{step}</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* METHOD */}
          <div style={{ background: "#0A0E18", border: `1px solid ${skill.color}30`, borderRadius: 12, padding: 20, marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <span style={{ fontSize: 18 }}>🧠</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: skill.accent, textTransform: "uppercase", letterSpacing: 1 }}>The Best Way to Learn This</span>
            </div>
            <p style={{ color: "#9CA3AF", fontSize: 14, lineHeight: 1.75, margin: 0 }}>{lesson.method}</p>
          </div>

          {/* EXERCISE */}
          <div style={{ background: "#0E0A00", border: "1px solid #92400E40", borderRadius: 12, padding: 20, marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <span style={{ fontSize: 18 }}>💪</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: "#FCD34D", textTransform: "uppercase", letterSpacing: 1 }}>Your Practice Exercise</span>
            </div>
            <p style={{ color: "#D97706", fontSize: 14, lineHeight: 1.75, margin: 0 }}>{lesson.exercise}</p>
          </div>

          {/* TIP */}
          {lesson.tip && (
            <div style={{ background: "#0A100A", border: "1px solid #16A34A30", borderRadius: 10, padding: 16, marginBottom: 24 }}>
              <p style={{ color: "#6B7280", fontSize: 13, lineHeight: 1.65, margin: 0 }}>{lesson.tip}</p>
            </div>
          )}

          {/* Navigation between lessons */}
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            {lessonIdx > 0
              ? <button onClick={() => { setLessonIdx(lessonIdx - 1); setOpenStep(null); window.scrollTo(0,0); }} style={{ background: "#0D0D14", border: "1px solid #1C1C28", borderRadius: 10, padding: "12px 18px", cursor: "pointer", color: "#6B7280", fontSize: 13 }}>← Previous Lesson</button>
              : <button onClick={() => setView("skill")} style={{ background: "#0D0D14", border: "1px solid #1C1C28", borderRadius: 10, padding: "12px 18px", cursor: "pointer", color: "#6B7280", fontSize: 13 }}>← All Lessons</button>
            }
            {lessonIdx < level.lessons.length - 1
              ? <button onClick={() => { setLessonIdx(lessonIdx + 1); setOpenStep(null); window.scrollTo(0,0); }} style={{ background: skill.color, border: "none", borderRadius: 10, padding: "12px 20px", cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 700 }}>Next Lesson →</button>
              : levelIdx < skill.levels.length - 1
                ? <button onClick={() => { setLevelIdx(levelIdx + 1); setLessonIdx(null); setView("skill"); window.scrollTo(0,0); }} style={{ background: skill.color, border: "none", borderRadius: 10, padding: "12px 20px", cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 700 }}>Next Level: {skill.levels[levelIdx + 1].name} →</button>
                : <div style={{ background: "#0D0D14", border: `1px solid ${skill.color}50`, borderRadius: 10, padding: "12px 20px", color: skill.accent, fontSize: 13, fontWeight: 700 }}>👑 Track Complete!</div>
            }
          </div>
        </div>
      </div>
    );
  }

  return null;
}
